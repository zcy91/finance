<?php
namespace Vendor\com\alibaba\openapi\client\entity;

class ResponseStatus{
	var $code;
	var $message;
	
	
}
?>