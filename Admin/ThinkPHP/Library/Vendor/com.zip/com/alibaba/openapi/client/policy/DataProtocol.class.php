<?php
namespace Vendor\com\alibaba\openapi\client\policy;

class DataProtocol {
	const param2 = "param2";
	const json2 = "json2";
	const xml2 = "xml2";
	const param = "param";
	const json = "json";
	const xml = "xml";
	const http = "http";
}
?>