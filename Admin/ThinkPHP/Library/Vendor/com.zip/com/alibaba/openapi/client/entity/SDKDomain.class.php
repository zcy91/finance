<?php
namespace Vendor\com\alibaba\openapi\client\entity;

class SDKDomain {
	
}


?>