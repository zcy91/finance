<?php
namespace Vendor\com\alibaba\openapi\client\util;

class ExceptionParser {


    public static function buildException4Json2() {
        
    }
}
?>