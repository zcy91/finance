<?php
namespace Vendor\com\alibaba\openapi\client\entity;

class ResponseWrapper {
	/**
	 *
	 * @var unknown
	 */
	var $responseStatus;
	
	/**
	 *
	 * @var unknown
	 */
	var $invokeStartTime;
	
	/**
	 *
	 * @var unknown
	 */
	var $invokeCostTime;
	
	/**
	 *
	 * @var unknown
	 */
	var $result;
}
?>